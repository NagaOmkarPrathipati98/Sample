package com.modak.Kafka;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/kafka")
public class KafkaController
{
    static final String TOPIC = "bhpl-success-event";
    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;
    // Implementing a POST method
    @PostMapping("publish/post")
    public ObjectNode publish_message(@RequestBody ObjectNode json) throws Exception
    {
        int count = 5;
        try
        {

            Process pg=null;
            ProcessBuilder pb=new ProcessBuilder();
            pb.command("sh","src/main/resources/final.sh","src/main/resources/service-account.JSON");
            pb.redirectErrorStream(true);
            pg=pb.start();
            //String [] args={"sh","C:\\Users\\GUA7021\\Desktop\\final.sh"};
            //pg=Runtime.getRuntime().exec(args);
            Gson gson = new Gson();
            JsonObject jsonobj = gson.fromJson(json.toString(), JsonObject.class);
            String z = jsonobj.get("filepath").getAsString();
            json.put("filecount", count);
            //int x=pg.waitFor();
            //System.out.println("value of x:"+x);
            BufferedReader reader = new BufferedReader(new InputStreamReader(pg.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ( (line = reader.readLine()) != null)
            {
                builder.append(line);
                System.out.println(line);

            }
            String result = builder.toString();
            System.out.println(result);
            System.out.println("end of script execution");
            json.put("recordcount",result);
            kafkaTemplate.send(TOPIC, json.toString());
            kafkaTemplate.flush();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return json;
    }
}
