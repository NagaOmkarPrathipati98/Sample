package com.example.BHPLMetadataCheck.Controller;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.ListBlobItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.kafka.core.KafkaTemplate;
import com.azure.spring.autoconfigure.storage.resource.AzureStorageResourcePatternResolver;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.example.BHPLMetadataCheck.Utils;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.dbutils.QueryRunner;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import java.io.IOException;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.util.stream.Collectors.toList;


@RestController
@RequestMapping("nabu")
public class AzureController
{
    Logger logger= LoggerFactory.getLogger(AzureController.class);
    Utils utils = new Utils();
    static final String TOPIC = "bhpl-success-event";
    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;
    public CloudBlobClient cloudBlobClient(String connectionString) throws URISyntaxException, StorageException, InvalidKeyException
    {
        //CloudStorageAccount storageAccount = CloudStorageAccount.parse(environment.getProperty("azure.storage.ConnectionString"));
        CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
        return storageAccount.createCloudBlobClient();
    }
    //Fetching total number of Parquet files count at the destination
    private int fileCount(String filepath, String containerName, String connectionString) throws Exception
    {
        System.out.println(containerName);
        int count = 0;
        List uris = new ArrayList<>();
        CloudBlobContainer container =cloudBlobClient(connectionString).getContainerReference(containerName);
        for (ListBlobItem blobItem : container.listBlobs(filepath,true))
        {
            uris.add(blobItem.getUri());
            count++;
        }
        count=count-1;
        return count;
    }
    // Implementing a POST method
    @PostMapping("successEvent/publish")
    public ObjectNode publish_message(@RequestParam String containerName,@RequestBody ObjectNode json) throws Exception
    {
        Gson gson = new Gson();
        JsonObject jsonobj = gson.fromJson(json.toString(), JsonObject.class);
        String dest_path = jsonobj.get("path").getAsString();
        String jwt_token = jsonobj.get("jwt_token").getAsString();
        int destination_cred_id=jsonobj.get("destination_credential_id").getAsInt();
        int destination_type_id=jsonobj.get("destination_credential_type_id").getAsInt();
        //Destination Details
        JsonObject destinationDetails = utils.getSourceCredentialInfo(jwt_token, destination_cred_id, destination_type_id);
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();
        String accountname=destinationData.get("accountname").getAsString();
        String accountkey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountname+accountkey);
        String connectionString = "DefaultEndpointsProtocol=https;AccountName="+accountname+";" +
                "AccountKey="+accountkey+";";
        String endpoint = "https://"+accountname+".blob.core.windows.net/";
        try
        {
            int filecount=fileCount(dest_path,containerName,connectionString);
            json.remove("jwt_token");
            json.remove("destination_credential_id");
            json.remove("destination_credential_type_id");

            //String recordcount=recordCount(dest_path,containerName);
            json.put("file_count", filecount);
            String output=json.toString().toUpperCase();
            kafkaTemplate.send(TOPIC,output);
            //kafkaTemplate.flush();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return json;
    }

    private static String toCSV(List<Map<String, Object>> list)
    {
        List<String> headers = list.stream().flatMap(map -> map.keySet().stream()).distinct().collect(toList());
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < headers.size(); i++) {
            sb.append(headers.get(i));
            sb.append(i == headers.size()-1 ? "\n" : ",");
        }
        for (Map<String, Object> map : list) {
            for (int i = 0; i < headers.size(); i++) {
                sb.append(map.get(headers.get(i)));
                sb.append(i == headers.size()-1 ? "\n" : ",");
            }
        }
        return sb.toString();
    }

    @PostMapping("/writeMetadataFile")
    public String writeMetadataFile(@RequestParam(value = "blobLocation") String blobLocation,
                                    @RequestBody JsonNode metadataInfo)
            throws Exception
    {

        Gson gson = new Gson();
        JsonObject metadataJson= gson.fromJson(metadataInfo.toString(),JsonObject.class);
        String jwt_token = metadataJson.get("jwt_token").getAsString();
        int destination_cred_id = metadataJson.get("destination_credential_id").getAsInt();
        int destination_type_id = metadataJson.get("destination_credential_type_id").getAsInt();
        String blobInfo= metadataJson.get("blobInfo").getAsString();

        //Destination Details
        JsonObject destinationDetails = utils.getSourceCredentialInfo(jwt_token, destination_cred_id, destination_type_id);
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();
        String accountname=destinationData.get("accountname").getAsString();
        String accountkey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountname+accountkey);

        String searchLocation = "azure-blob://" + blobLocation;
        String connectionString = "DefaultEndpointsProtocol=https;AccountName="+accountname+";" +
                "AccountKey="+accountkey+";";
        String endpoint = "https://"+accountname+".blob.core.windows.net/";

        BlobServiceClient client = new BlobServiceClientBuilder().connectionString(connectionString).endpoint(endpoint)
                .buildClient();
        AzureStorageResourcePatternResolver storageResourcePatternResolver =
                new AzureStorageResourcePatternResolver(client);
        System.out.println(storageResourcePatternResolver);
        Resource resource = storageResourcePatternResolver.getResource(searchLocation);
        System.out.println(resource);
        OutputStream os = ((WritableResource) resource).getOutputStream();
        os.write(blobInfo.getBytes());
        os.flush();
        os.close();
        System.out.println(resource.getFilename());
        //System.out.println(body);
        return "Metadata File updated";
    }

    @PostMapping("/writeReconFile")
    public String writeReconFile(@RequestBody JsonNode json, @RequestParam String blobLocation)
            throws Exception
    {
        System.out.println("Recon1 - Http request received");
        Gson gson = new Gson();
        JsonObject reconJson = gson.fromJson(json.toString(), JsonObject.class);
        String jwt_token = reconJson.get("jwt_token").getAsString();
        int source_cred_id = reconJson.get("source_credential_id").getAsInt();
        int source_cred_type_id = reconJson.get("source_credential_type_id").getAsInt();
        int destination_cred_id = reconJson.get("destination_credential_id").getAsInt();
        int destination_type_id = reconJson.get("destination_credential_type_id").getAsInt();
        String jdbc_driver=reconJson.get("jdbc_driver").getAsString();
        String db_url=reconJson.get("db_url").getAsString();
        String query = reconJson.get("query").getAsString();
        System.out.println("");
        //Destination Details
        JsonObject destinationDetails = utils.getSourceCredentialInfo(jwt_token, destination_cred_id, destination_type_id);
        if(destinationDetails != null)
        {
            System.out.println("Recon-1  These are the destination details: "+destinationDetails);
            logger.warn("Recon-1 In the warn,These are the destination details: "+destinationDetails);

        }
        else
        {
            System.out.println("Recon-1 destination details is null");
        }
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();

        if(destinationData != null)
        {
            System.out.println("Recon-1 These are the destination data: "+destinationData);
            logger.warn("Recon-1 In the warn,These are the destination data: "+destinationData);
        }
        else
        {
            System.out.println("Recon-1 destination data is null");
        }
        String accountname=destinationData.get("accountname").getAsString();
        String accountkey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountname+accountkey);
        //Source Details
        JsonObject sourceDetails = utils.getSourceCredentialInfo(jwt_token, source_cred_id, source_cred_type_id);
        JsonObject sourceData = sourceDetails.get("data").getAsJsonObject();
        String password = sourceData.get("password").getAsString();
        String username = sourceData.get("username").getAsString();
        System.out.println("Source Details"+username + password);
        QueryRunner queryRunner = new QueryRunner();
        Connection conn;
        //Step 1: Register JDBC driver
        DbUtils.loadDriver(jdbc_driver);
        //Step 2: Open a connection
        System.out.println("Connecting to database...");
        conn = DriverManager.getConnection(db_url, username, password);
        List result
                = queryRunner.query(conn, query, new MapListHandler());
        System.out.println(result);
        String csv=toCSV(result);
        String searchLocation = "azure-blob://" + blobLocation;
        String connectionString = "DefaultEndpointsProtocol=https;AccountName="+accountname+";" +
                "AccountKey="+accountkey+";";
        String endpoint = "https://"+accountname+".blob.core.windows.net/";
        BlobServiceClient client = new BlobServiceClientBuilder().connectionString(connectionString).endpoint(endpoint)
                .buildClient();
        AzureStorageResourcePatternResolver storageResourcePatternResolver =
                new AzureStorageResourcePatternResolver(client);
        System.out.println(storageResourcePatternResolver);
        Resource resource = storageResourcePatternResolver.getResource(searchLocation);
        System.out.println(resource);
        OutputStream os = ((WritableResource) resource).getOutputStream();
        System.out.println("Decoded string: "+csv);
        os.write(csv.getBytes(StandardCharsets.UTF_8));
        os.flush();
        os.close();
        DbUtils.close(conn);
        return "Recon File Updated";
    }

}
