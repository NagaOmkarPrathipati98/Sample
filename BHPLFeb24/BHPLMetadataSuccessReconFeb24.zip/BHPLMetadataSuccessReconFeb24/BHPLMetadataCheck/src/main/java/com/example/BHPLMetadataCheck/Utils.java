package com.example.BHPLMetadataCheck;
import com.example.BHPLMetadataCheck.Controller.AzureController;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class Utils {
    Logger logger= LoggerFactory.getLogger(Utils.class);
    public static CloseableHttpClient getCloseableHttpClient()
    {
        CloseableHttpClient httpClient = null;
        try {
            httpClient = HttpClients.custom().
                    setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).
                    setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy()
                    {
                        public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException
                        {
                            return true;
                        }
                    }).build()).build();
        } catch (KeyManagementException kme) {
            kme.printStackTrace();
        } catch (NoSuchAlgorithmException nse) {
            nse.printStackTrace();
        } catch (KeyStoreException kse) {
            kse.printStackTrace();
        }
        return httpClient;
    }

    public String getAuthToken(){
        CloseableHttpClient httpClient = getCloseableHttpClient();
        HttpPost post = new HttpPost("https://dev-dha.humana.com:8888/fireshots/login?service=nabu");
        String token = "";
        try {
            String credentials="{\n" +
                    "    \"userId\":\"nabuadmin\",\n" +
                    "    \"password\":\"admin\"\n" +
                    "}";

            post.setEntity(new StringEntity(credentials));

            HttpResponse response = httpClient.execute(post);

            if(response.getStatusLine().getStatusCode() == 200)
            {
                String json = EntityUtils.toString(response.getEntity());
                //JsonObject jsonObject=response.getEntity().;
                Gson gson=new Gson();
                JsonObject jsonObject= gson.fromJson(json,JsonObject.class);
                JsonPrimitive jsonPrimitive=jsonObject.getAsJsonPrimitive("token");
                token=jsonPrimitive.toString().replaceAll("\"","");
                return token;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return token;
    }
    public JsonObject getCredentialInfo(String token, Integer credential_id){

        token=getAuthToken();

        CloseableHttpClient httpClient = getCloseableHttpClient();
        //HttpPost post = new HttpPost("https://dev-dha.humana.com:8888/fireshots/nabu/sel/select/restCatalog/credentials");
        //HttpPost post = new HttpPost("https://dev-dha.humana.com:8888/fireshots/credentialsFetchWebService");
        HttpPost post = new HttpPost("https://dev-dha.humana.com:8888/fireshots/nabu/sel/sq/manageVaultCredentials/selectCredentials");
        JsonObject credentialInfo=null;
        try {
            post.addHeader("Authorization",token);
            String body="{\n" +
                    "    \"credential_id\": "+credential_id+",\n" +
                    "    \"vault_id\": 1\n" +
                    "}";
            post.setEntity(new StringEntity(body));


            HttpResponse response = httpClient.execute(post);
            if(response.getStatusLine().getStatusCode() == 200)
            {
                String json = EntityUtils.toString(response.getEntity());
                Gson gson=new Gson();
                credentialInfo= gson.fromJson(json,JsonObject.class);
                return credentialInfo;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return credentialInfo;
    }

    public JsonObject getSourceCredentialInfo(String jwt_token, int credential_id, int credential_type_id){
        System.out.println("jwt_token is "+jwt_token + "\n" + "credential id is " + credential_id+ "\n" + "credential type id is " + credential_type_id);
        logger.warn("Recon-1 jwt_token is "+jwt_token + "\n" + "credential id is " + credential_id+ "\n" + "credential type id is " + credential_type_id);
        CloseableHttpClient httpClient = getCloseableHttpClient();
        HttpPost post = new HttpPost("https://dev-dha.humana.com:8888/fireshots/credentialsFetchWebService");
        JsonObject credentialInfo=null;
        try {
            post.addHeader("Authorization",jwt_token);
            String body="{\n" +
                    "    \"credential_id\": "+credential_id+",\n" +
                    "    \"credential_type_id\":"+credential_type_id+"\n" +
                    "}";
            post.setEntity(new StringEntity(body));
            System.out.println(body);
            HttpResponse response = httpClient.execute(post);
            if(response.getStatusLine().getStatusCode() == 200)
            {
                String json = EntityUtils.toString(response.getEntity());
                Gson gson=new Gson();
                credentialInfo= gson.fromJson(json,JsonObject.class);
//                JsonObject data=credentialInfo.get("data").getAsJsonObject();
//                String password=data.get("password").getAsString();
//                String username=data.get("username").getAsString();
//                System.out.println(username+password);
                logger.warn("Recon-1 this is the credentialInfo:" + credentialInfo);
                return credentialInfo;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.warn("Recon-1(Out of try-catch) this is the credentialInfo:" + credentialInfo);
        return credentialInfo;
    }
}
