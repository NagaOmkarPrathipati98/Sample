package com.example.BHPLMetadataCheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BhplMetadataCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
