package com.BHPL.RestApplicationService;

import com.azure.core.amqp.AmqpTransportType;
import com.azure.messaging.eventhubs.EventData;
import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubClientBuilder;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.springframework.kafka.core.KafkaTemplate;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.dbutils.QueryRunner;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;

@RestController
@RequestMapping("nabu")
public class BHPLRestServiceController
{
    @Autowired
    Environment environment;
    NabuAPIUtility nabuAPIUtility=new NabuAPIUtility();
    ConversionUtility conversionUtility=new ConversionUtility();
    AzureUtility azureUtility=new AzureUtility();


//    @Value("${eventhubConnectionString}")
//    private String eventhubConnectionString;
//    @Value("${eventHubName}")
//    private String eventHubName;

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @PostMapping("eventHub/publish")
    public ObjectNode publish_message(@RequestParam String containerName, @RequestBody ObjectNode json)
    {
        String eventhubConnectionString = environment.getProperty("eventhubConnectionString");
        String eventHubName = environment.getProperty("eventHubName");
        //Create Producer client to send messages to the event hub.
        EventHubProducerClient producer = new EventHubClientBuilder()
                .connectionString(eventhubConnectionString, eventHubName)//Specify connection string to the event hubs namespace and the event hub namespace.
                .transportType(AmqpTransportType.AMQP_WEB_SOCKETS)
                .buildProducerClient();

        //Creating a batch.
        EventDataBatch eventDataBatch = producer.createBatch();
        //incoming JSON body parsing
        Gson gson = new Gson();
        JsonObject jsonobj = gson.fromJson(json.toString(), JsonObject.class);
        String dest_path = jsonobj.get("path").getAsString();
        String jwt_token = jsonobj.get("jwt_token").getAsString();
        int destination_cred_id=jsonobj.get("destination_credential_id").getAsInt();
        int destination_type_id=jsonobj.get("destination_credential_type_id").getAsInt();

        //Destination Details
        JsonObject destinationDetails = nabuAPIUtility.getCredentialsInfoFromNabu(jwt_token, destination_cred_id, destination_type_id);
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();

        String accountName=destinationData.get("accountname").getAsString();
        String accountKey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountName+accountKey);
        String connectionString = "DefaultEndpointsProtocol=https;AccountName="+accountName+";" +
                "AccountKey="+accountKey+";";

        try
        {
            int filecount=azureUtility.fileCount(dest_path,containerName,connectionString);
            json.put("file_count", filecount);
            json.remove("jwt_token");
            json.remove("destination_credential_id");
            json.remove("destination_credential_type_id");
            String output=json.toString().toUpperCase();

            //Adding event data
            EventData data=new EventData(output);

            //Adding events to that batch.
            eventDataBatch.tryAdd(data);

            //Sending batch of events to the event hub.
            producer.send(eventDataBatch);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            producer.close();
            return json;
        }

    }

    @PostMapping("successEvent/publish")
    public ObjectNode publishSuccessEventOnKafka(@RequestParam String containerName,@RequestBody ObjectNode json) throws Exception
    {
        final String topic=environment.getProperty("topic");
        Gson gson = new Gson();
        JsonObject jsonobj = gson.fromJson(json.toString(), JsonObject.class);
        String dest_path = jsonobj.get("path").getAsString();
        String jwt_token = jsonobj.get("jwt_token").getAsString();
        int destination_cred_id=jsonobj.get("destination_credential_id").getAsInt();
        int destination_type_id=jsonobj.get("destination_credential_type_id").getAsInt();

        //Destination Details
        JsonObject destinationDetails = nabuAPIUtility.getCredentialsInfoFromNabu(jwt_token, destination_cred_id, destination_type_id);
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();

        String accountName=destinationData.get("accountname").getAsString();
        String accountKey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountName+accountKey);
        String connectionString = "DefaultEndpointsProtocol=https;AccountName="+accountName+";" +
                "AccountKey="+accountKey+";";
        try
        {
            int filecount=azureUtility.fileCount(dest_path,containerName,connectionString);
            json.remove("jwt_token");
            json.remove("destination_credential_id");
            json.remove("destination_credential_type_id");

            //String recordcount=recordCount(dest_path,containerName);
            json.put("file_count", filecount);
            String successMessage=json.toString().toUpperCase();
            kafkaTemplate.send(topic,successMessage);
            //kafkaTemplate.flush();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return json;
    }

    @PostMapping("/writeMetadataFile")
    public String writeMetadataFile(@RequestParam(value = "blobLocation") String blobLocation,
                                    @RequestBody JsonNode metadataInfo)
            throws Exception
    {
        Gson gson = new Gson();
        JsonObject metadataJson= gson.fromJson(metadataInfo.toString(),JsonObject.class);
        String jwt_token = metadataJson.get("jwt_token").getAsString();
        int destination_cred_id = metadataJson.get("destination_credential_id").getAsInt();
        int destination_type_id = metadataJson.get("destination_credential_type_id").getAsInt();

        String blobInfo= metadataJson.get("blobInfo").getAsString().toUpperCase();
        //String blobInfoUpperCase = blobInfo.toUpperCase();
        //Destination Details
        JsonObject destinationDetails = nabuAPIUtility.getCredentialsInfoFromNabu(jwt_token, destination_cred_id, destination_type_id);
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();
        String accountname=destinationData.get("accountname").getAsString();
        String accountkey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountname+accountkey);

        Resource resource= azureUtility.getResource(blobLocation,accountname,accountkey);

        System.out.println(resource);
        OutputStream os = ((WritableResource) resource).getOutputStream();
        os.write(blobInfo.getBytes());
        os.flush();
        os.close();
        System.out.println(resource.getFilename());
        return "Metadata File updated";
    }

    @PostMapping("/writeReconFile")
    public String writeReconFile(@RequestBody JsonNode json, @RequestParam String blobLocation)
            throws Exception
    {

        Gson gson = new Gson();
        JsonObject reconJson = gson.fromJson(json.toString(), JsonObject.class);
        String jwtToken = reconJson.get("jwt_token").getAsString();
        int sourceCredentialId = reconJson.get("source_credential_id").getAsInt();
        int sourceCredentialTypeId = reconJson.get("source_credential_type_id").getAsInt();
        int destinationCredentialId = reconJson.get("destination_credential_id").getAsInt();
        int destinationCredentialTypeId = reconJson.get("destination_credential_type_id").getAsInt();
        String jdbc_driver=reconJson.get("jdbc_driver").getAsString();
        String dbUrl=reconJson.get("db_url").getAsString();
        String query = reconJson.get("query").getAsString();

        //Destination Details -- Acquiring the details of destination.
        JsonObject destinationDetails = nabuAPIUtility.getCredentialsInfoFromNabu(jwtToken, destinationCredentialId, destinationCredentialTypeId);
        JsonObject destinationData=destinationDetails.get("data").getAsJsonObject();
        String accountName=destinationData.get("accountname").getAsString();
        String accountKey=destinationData.get("accountkey").getAsString();
        System.out.println("Destination Details:"+accountName+accountKey);

        //Source Details -- Acquiring the details of Source
        JsonObject sourceDetails = nabuAPIUtility.getCredentialsInfoFromNabu(jwtToken, sourceCredentialId, sourceCredentialTypeId);
        JsonObject sourceData = sourceDetails.get("data").getAsJsonObject();
        String password = sourceData.get("password").getAsString();
        String username = sourceData.get("username").getAsString();
        System.out.println("Source Details"+username + password);

        QueryRunner queryRunner = new QueryRunner();
        Connection sourceJDBCConnection = null;
        List reconSQLOutput = null;
        //Step 1: Register JDBC drive
        try {
            DbUtils.loadDriver(jdbc_driver);
            //Step 2: Open a connection
            System.out.println("Connecting to database...");
            sourceJDBCConnection = DriverManager.getConnection(dbUrl, username, password);
            reconSQLOutput  = queryRunner.query(sourceJDBCConnection, query, new MapListHandler());
            System.out.println(reconSQLOutput);

        } catch (Exception ex){
            ex.printStackTrace();
        } finally {
            //CLose the connection
            DbUtils.close(sourceJDBCConnection);
        }
        String reconSQLOutputInCSV= conversionUtility.convertMapToCSV(reconSQLOutput).toUpperCase();
        Resource resource= azureUtility.getResource(blobLocation,accountName,accountKey);
        OutputStream os = ((WritableResource) resource).getOutputStream();
        System.out.println("Decoded string: "+reconSQLOutputInCSV);
        os.write(reconSQLOutputInCSV.getBytes(StandardCharsets.UTF_8));
        os.flush();
        os.close();

        return "Recon File Updated";
    }

}
