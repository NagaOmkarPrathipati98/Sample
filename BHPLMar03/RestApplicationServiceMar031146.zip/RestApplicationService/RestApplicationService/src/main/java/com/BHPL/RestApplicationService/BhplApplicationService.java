package com.BHPL.RestApplicationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BhplApplicationService {

	public static void main(String[] args) {
		SpringApplication.run(BhplApplicationService.class, args);
	}

}
