package com.BHPL.RestApplicationService;

import com.azure.spring.autoconfigure.storage.resource.AzureStorageResourcePatternResolver;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.ListBlobItem;
import org.springframework.core.io.Resource;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.List;

public class AzureUtility {

    public CloudBlobClient getCloudBlobClient(String connectionString) throws URISyntaxException, StorageException, InvalidKeyException
    {
        CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
        return storageAccount.createCloudBlobClient();
    }

    public int fileCount(String filepath, String containerName, String connectionString) throws Exception
    {
        System.out.println(containerName);
        int count = 0;
        List uris = new ArrayList<>();
        CloudBlobContainer container = getCloudBlobClient(connectionString).getContainerReference(containerName);
        for (ListBlobItem blobItem : container.listBlobs(filepath,true))
        {
            uris.add(blobItem.getUri());
            count++;
        }
        count=count-1;
        return count;
    }

    public Resource getResource(String blobLocation, String accountname, String accountkey){
        String searchLocation = "azure-blob://" + blobLocation;
        String connectionString = "DefaultEndpointsProtocol=https;AccountName="+accountname+";" +
                "AccountKey="+accountkey+";";
        String endpoint = "https://"+accountname+".blob.core.windows.net/";

        BlobServiceClient client = new BlobServiceClientBuilder().connectionString(connectionString).endpoint(endpoint)
                .buildClient();
        AzureStorageResourcePatternResolver storageResourcePatternResolver =
                new AzureStorageResourcePatternResolver(client);
        System.out.println(storageResourcePatternResolver);
        Resource resource = storageResourcePatternResolver.getResource(searchLocation);
        System.out.println(resource);
        return resource;
    }
}
