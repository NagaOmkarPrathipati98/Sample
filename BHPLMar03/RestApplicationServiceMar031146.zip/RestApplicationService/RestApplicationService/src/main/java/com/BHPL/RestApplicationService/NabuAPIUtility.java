package com.BHPL.RestApplicationService;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

@Component
public class NabuAPIUtility {

    @Autowired
    Environment environment;

//    String nabuCredentials=environment.getProperty("nabuCredentials");
//    String nabuLoginEndpoint=environment.getProperty("nabuLoginEndpoint");
//    String fetchCredentialsEndpoint=environment.getProperty("fetchCredentialsEndpoint");

    public static CloseableHttpClient getCloseableHttpClient()
    {
        CloseableHttpClient httpClient = null;
        try {
            httpClient = HttpClients.custom().
                    setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).
                    setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy()
                    {
                        public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException
                        {
                            return true;
                        }
                    }).build()).build();
        } catch (KeyManagementException kme) {
            kme.printStackTrace();
        } catch (NoSuchAlgorithmException nse) {
            nse.printStackTrace();
        } catch (KeyStoreException kse) {
            kse.printStackTrace();
        }
        return httpClient;
    }

    public String getNabuAuthToken(){
        String nabuCredentials=environment.getProperty("nabuCredentials");
        String nabuLoginEndpoint=environment.getProperty("nabuLoginEndpoint");
        CloseableHttpClient httpClient = getCloseableHttpClient();
        HttpPost post = new HttpPost(nabuLoginEndpoint);
        String token = "";
        try {
            String credentials=nabuCredentials;

            post.setEntity(new StringEntity(credentials));

            HttpResponse response = httpClient.execute(post);

            if(response.getStatusLine().getStatusCode() == 200)
            {
                String json = EntityUtils.toString(response.getEntity());
                //JsonObject jsonObject=response.getEntity().;
                Gson gson=new Gson();
                JsonObject jsonObject= gson.fromJson(json,JsonObject.class);
                JsonPrimitive jsonPrimitive=jsonObject.getAsJsonPrimitive("token");
                token=jsonPrimitive.toString().replaceAll("\"","");
                return token;
            }else
            {
                System.out.println("Status code is not 200"+ response.getStatusLine());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return token;
    }
    //method comments
    public JsonObject getCredentialsInfoFromNabu(String jwt_token, int credential_id, int credential_type_id){
        CloseableHttpClient httpClient = getCloseableHttpClient();
        //add in app.pro
        String fetchCredentialsEndpoint=environment.getProperty("fetchCredentialsEndpoint");
        HttpPost postRequest = new HttpPost(fetchCredentialsEndpoint);
        JsonObject credentialInfo=null;
        try {
            postRequest.addHeader("Authorization",jwt_token);
            String requestBody="{\n" +
                    "    \"credential_id\": "+credential_id+",\n" +
                    "    \"credential_type_id\":"+credential_type_id+"\n" +
                    "}";
            postRequest.setEntity(new StringEntity(requestBody));
            System.out.println(requestBody);
            HttpResponse postResponse = httpClient.execute(postRequest);
            if(postResponse.getStatusLine().getStatusCode() == 200)
            {
                String json = EntityUtils.toString(postResponse.getEntity());
                Gson gson=new Gson();
                credentialInfo= gson.fromJson(json,JsonObject.class);
                return credentialInfo;
            }
            else
            {
                System.out.println("Status code is not 200"+ postResponse.getStatusLine());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return credentialInfo;
    }
}
