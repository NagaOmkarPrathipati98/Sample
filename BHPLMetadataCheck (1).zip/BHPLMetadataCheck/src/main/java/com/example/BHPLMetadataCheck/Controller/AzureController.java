package com.example.BHPLMetadataCheck.Controller;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.ListBlobItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.kafka.core.KafkaTemplate;
import com.azure.spring.autoconfigure.storage.resource.AzureStorageResourcePatternResolver;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.example.BHPLMetadataCheck.Utils;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.dbutils.QueryRunner;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import java.io.IOException;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@RestController
@RequestMapping("nabu")
public class AzureController
{
    Utils utils = new Utils();
    @Autowired
    private Environment environment;
    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;
    @Bean
    public CloudBlobClient cloudBlobClient() throws URISyntaxException, StorageException, InvalidKeyException
    {
        CloudStorageAccount storageAccount = CloudStorageAccount.parse(environment.getProperty("azure.storage.ConnectionString"));
        return storageAccount.createCloudBlobClient();
    }
    private static String toCSV(List<Map<String, Object>> list)
    {
        List<String> headers = list.stream().flatMap(map -> map.keySet().stream()).distinct().collect(toList());
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < headers.size(); i++) {
            sb.append(headers.get(i));
            sb.append(i == headers.size()-1 ? "\n" : ",");
        }
        for (Map<String, Object> map : list) {
            for (int i = 0; i < headers.size(); i++) {
                sb.append(map.get(headers.get(i)));
                sb.append(i == headers.size()-1 ? "\n" : ",");
            }
        }
        return sb.toString();
    }
    @PostMapping("success/produceKafka")
    public ObjectNode listBlobs(@RequestParam String containerName, @RequestBody ObjectNode json) throws Exception
    {
        final String TOPIC = "bhpl-success-event";
        List uris = new ArrayList<>();
        int count = 0;
        Gson gson = new Gson();
        JsonObject jsonobj = gson.fromJson(json.toString(), JsonObject.class);
        String dest_path = jsonobj.get("filepath").getAsString();
        try
        {
            System.out.println(containerName);
            CloudBlobContainer container = cloudBlobClient().getContainerReference(containerName);
            for (ListBlobItem blobItem : container.listBlobs(dest_path, true))
            {
                uris.add(blobItem.getUri());
                count++;
            }
            count = count - 2;
            json.put("filecount", count);
            kafkaTemplate.send(TOPIC, json.toString());
            //kafkaTemplate.flush();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (StorageException e) {
            e.printStackTrace();
        }
        return json;
    }

    @PostMapping("/writeMetadataFile")
    public String writeMetadataFile(@RequestParam(value = "blobLocation") String blobLocation, @RequestBody String blobInfo)
            throws IOException
    {
        String token=utils.getAuthToken();
        System.out.println("The Auth Token is " + token);
        String searchLocation = "azure-blob://" + blobLocation;
        String connectionString = "DefaultEndpointsProtocol=https;AccountName=idea15pisplznonprodsa2;" +
                "AccountKey=cwZkbSxl+tWiMN6MLhz5LqfV2j1eMvowePab2vCVJnDg28ftkkiQqRvh7Iag+x+uts7DRUUupWmlbIPai1uYyQ==";
        String endpoint = "https://idea15pisplznonprodsa2.blob.core.windows.net/";
        BlobServiceClient client = new BlobServiceClientBuilder().connectionString(connectionString).endpoint(endpoint)
                .buildClient();
        AzureStorageResourcePatternResolver storageResourcePatternResolver =
                new AzureStorageResourcePatternResolver(client);
        System.out.println(storageResourcePatternResolver);
        Resource resource = storageResourcePatternResolver.getResource(searchLocation);
        System.out.println(resource);
        OutputStream os = ((WritableResource) resource).getOutputStream();
        os.write(blobInfo.getBytes());
        os.flush();
        os.close();
        System.out.println(resource.getFilename());
        //System.out.println(body);
        return "Metadata File updated";
    }

    @PostMapping("/writeReconFile")
    public String writeReconFile(@RequestBody JsonNode json, @RequestParam String blobLocation)
                throws IOException, SQLException, NullPointerException
    {
            System.out.println("Hitted Recon API ...");
            Gson gson = new Gson();
            JsonObject jsonobj = gson.fromJson(json.toString(), JsonObject.class);
            String jwt_token = jsonobj.get("jwt_token").getAsString();
            int source_cred_id = jsonobj.get("source_credential_id").getAsInt();
            int source_cred_type_id = jsonobj.get("source_credential_type_id").getAsInt();
            int destination_cred_id = jsonobj.get("destination_credential_id").getAsInt();
            int destination_type_id = jsonobj.get("destination_credential_type_id").getAsInt();
            String query = jsonobj.get("query").getAsString();

            JsonObject sourceDetails = utils.getSourceCredentialInfo(jwt_token, source_cred_id, source_cred_type_id);
            JsonObject destinationDetails = utils.getDestinationCredentialInfo(jwt_token, destination_cred_id, destination_type_id);

            JsonObject data = sourceDetails.get("data").getAsJsonObject();
            String password = data.get("password").getAsString();
            String username = data.get("username").getAsString();
            System.out.println(username + password);
            final String JDBC_DRIVER = "oracle.jdbc.OracleDriver";
            final String DB_URL = "jdbc:oracle:thin:@edwdev-scan.humana.com:1521/edwqa";
            QueryRunner queryRunner = new QueryRunner();
            Connection conn;
            //Step 1: Register JDBC driver
            DbUtils.loadDriver(JDBC_DRIVER);
            //Step 2: Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, username, password);
            List result
                    = queryRunner.query(conn, query, new MapListHandler());
            System.out.println(result);
            String csv=toCSV(result);
            String searchLocation = "azure-blob://" + blobLocation;
            String connectionString = "DefaultEndpointsProtocol=https;AccountName=idea15pisplznonprodsa2;" +
                    "AccountKey=cwZkbSxl+tWiMN6MLhz5LqfV2j1eMvowePab2vCVJnDg28ftkkiQqRvh7Iag+x+uts7DRUUupWmlbIPai1uYyQ==";
            String endpoint = "https://idea15pisplznonprodsa2.blob.core.windows.net/";
            BlobServiceClient client = new BlobServiceClientBuilder().connectionString(connectionString).endpoint(endpoint)
                    .buildClient();
            AzureStorageResourcePatternResolver storageResourcePatternResolver =
                    new AzureStorageResourcePatternResolver(client);
            System.out.println(storageResourcePatternResolver);
            Resource resource = storageResourcePatternResolver.getResource(searchLocation);
            System.out.println(resource);
            OutputStream os = ((WritableResource) resource).getOutputStream();
            System.out.println("Decoded string: "+csv);
            os.write(csv.getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            DbUtils.close(conn);
            return "Recon File Updated";
    }
}
